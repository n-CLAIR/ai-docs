import numpy as np
import os

def test_data_loader(root_path):
    """
    Data loader for test data

    :param root_path: path to the test dataset. root_path would be enough.
    :return: data type used in infer() function

    location of the test data is root_path/test/*
    """
    return np.loadtxt(os.path.join(root_path, 'test', 'test_data'), delimiter=',', dtype=np.float32)